import java.io.IOException;
import java.net.Socket;

public class MainServer {
    public static void main(String[] args) {
        int porta = 12345;
        try {
            Server server = new Server(porta);
            System.out.println("Server in ascolto");
            Socket socket = server.attendi();
            System.out.println("Server connesso al client");
        } catch (IOException e) {
            e.printStackTrace(); //System.err.println(e);
            System.exit(1);
        }
    }
}