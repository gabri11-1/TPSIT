import java.net.Socket;

public class Client {
    private String nome;
    private String colore;
    private Socket socket;

    public Client(String nome) {
        this.nome = nome;
    }

    int connetti(String nomeServer, int portaServer) {
        return 0;
    }

    void scrivi() {
    }

    void leggi() {
    }

    void chiudi() {
    }

}