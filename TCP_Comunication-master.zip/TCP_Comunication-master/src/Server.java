import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {
    private ServerSocket severSocket;
    private Socket socket;
    private int porta;

    public Server(int porta) throws IOException {
        this.porta = porta;

        severSocket = new ServerSocket(porta);
    }

    public Socket attendi() {
        try {
            socket = severSocket.accept();
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("il server non riesce ad instaurare la connessione");
        }
        return socket;
    }

    void scrivi() {
    }

    void leggi() {
    }

    void chiudi() {
    }

    void termina() {
    }
}
